import express from 'express';
import { YemotRouter } from 'yemot-router2';
import { randomUUID } from 'node:crypto';
import { getConfig, saveConfig, PRESETS, isAllowed, isOpen } from './lib/config.js';
import { respond } from './lib/ai.js';
import { synth, cleanForSpeech } from './lib/tts.js';
import { uploadWav } from './lib/yemot.js';
import { adminApi } from './lib/admin.js';

const app = express();
app.use(express.json({ limit: '1mb' }));
app.get('/healthz', (_q, r) => r.send('ok'));
app.use('/api', adminApi);   // אתר הניהול מתחבר לכאן

const router = YemotRouter({
  printLog: true,
  uncaughtErrorHandler: async (err, call) => {
    console.error('call error', err);
    return call.id_list_message([{ type: 'text', data: 'אירעה תקלה. אנא נסו שוב מאוחר יותר.' }]);
  }
});

// הופך טקסט להודעה שימות יכולה להשמיע, בקול של גוגל או בקול המובנה
async function toMessages(cfg, text, callId, n) {
  text = cleanForSpeech(text);
  if (cfg.voice.provider === 'google') {
    try {
      const path = `/ApiAudio/${callId}_${n}`;
      await uploadWav(await synth(text, cfg.voice), `${path}.wav`);
      return [{ type: 'file', data: path }];
    } catch (e) { console.error('TTS fallback to Yemot voice:', e.message); }
  }
  return [{ type: 'text', data: text }];
}

// ---------------- שלוחת הצ'אט ----------------
router.get('/chat', async (call) => {
  const cfg = await getConfig();
  const say = (t) => call.id_list_message([{ type: 'text', data: t }]);

  if (!cfg.enabled) { await say(cfg.closedMessage); return call.hangup(); }
  if (!isAllowed(cfg, call.phone)) { await say(cfg.deniedMessage); return call.hangup(); }
  if (!isOpen(cfg)) { await say(cfg.closedMessage); return call.hangup(); }

  const callId = randomUUID().slice(0, 8);
  const ctx = { call, assets: new Map(), ended: false };
  const history = [];
  const started = Date.now();
  let n = 0, silent = 0;
  let prompt = await toMessages(cfg, cfg.greeting, callId, n++);

  while (true) {
    // ההשמעה והאזנה באותה בקשה, כדי לחסוך זמן תגובה
    const heard = await call.read(prompt, 'stt', { lang: 'he-IL', record_ok: false });
    const text = String(heard || '').trim();

    if (!text) {
      if (++silent >= 3) break;
      prompt = await toMessages(cfg, silent === 1 ? 'אני כאן, אפשר לדבר.' : 'לא שמעתי אותך, אתה עדיין שם?', callId, n++);
      continue;
    }
    silent = 0;
    history.push({ role: 'user', parts: [{ text }] });

    const reply = await respond(history, cfg, ctx);
    if (ctx.ended || Date.now() - started > cfg.maxMinutes * 60000) {
      await call.id_list_message(await toMessages(cfg, reply || cfg.goodbye, callId, n++));
      return call.hangup();
    }
    prompt = await toMessages(cfg, reply, callId, n++);
  }
  await say(cfg.goodbye);
  return call.hangup();
});

// ---------------- שלוחת הגדרות בטלפון (מוגנת ב-PIN) ----------------
router.get('/admin', async (call) => {
  const pin = await call.read([{ type: 'text', data: 'הקישו קוד סודי' }], 'tap', { max_digits: 12, min_digits: 1 });
  if (!process.env.ADMIN_PIN || pin !== process.env.ADMIN_PIN) { await call.id_list_message([{ type: 'text', data: 'קוד שגוי' }]); return call.hangup(); }
  const cfg = await getConfig();
  const ids = Object.keys(PRESETS);
  const choice = await call.read([{ type: 'text',
    data: `למצב פעיל או כבוי הקישו 1. לבחירת תפקיד הקישו 2. כרגע השירות ${cfg.enabled ? 'פעיל' : 'כבוי'}.` }], 'tap', { max_digits: 1, min_digits: 1 });
  if (choice === '1') { await saveConfig({ enabled: !cfg.enabled }); await call.id_list_message([{ type: 'text', data: cfg.enabled ? 'השירות כובה' : 'השירות הופעל' }]); }
  if (choice === '2') {
    const menu = ids.map((id, i) => `${PRESETS[id].label} הקישו ${i + 1}`).join('. ');
    const c = await call.read([{ type: 'text', data: menu }], 'tap', { max_digits: 1, min_digits: 1 });
    const id = ids[Number(c) - 1];
    if (id) { await saveConfig({ role: id }); await call.id_list_message([{ type: 'text', data: 'התפקיד עודכן' }]); }
  }
  return call.hangup();
});

app.use('/', router);
app.listen(process.env.PORT || 8080, () => console.log('listening'));
